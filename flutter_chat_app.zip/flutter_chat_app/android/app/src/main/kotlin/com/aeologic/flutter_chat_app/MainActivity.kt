package com.aeologic.flutter_chat_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
