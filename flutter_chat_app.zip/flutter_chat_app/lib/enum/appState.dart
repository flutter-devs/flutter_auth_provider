enum ViewState { Ideal, Busy }
enum AuthState { SignIn, SignUp }
